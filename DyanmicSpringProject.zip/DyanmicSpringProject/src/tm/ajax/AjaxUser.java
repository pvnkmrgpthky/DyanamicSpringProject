package tm.ajax;


public class AjaxUser {
	public String dwrFuction()
	{
		StringBuffer sb=new StringBuffer();
		sb.append("Jul 04, 2016 11:26:48 AM org.apache.tomcat.util.digester.SetPropertiesRule begin@@@@@@@@@@@@1");
		sb.append("Jul 04, 2016 11:26:48 AM org.apache.catalina.startup.VersionLoggerListener log@@@2");
		
		return "";
	}

}
