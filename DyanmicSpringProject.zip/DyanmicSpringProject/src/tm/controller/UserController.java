package tm.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.StatelessSession;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import tm.bean.UserRegistration;
import tm.dao.UserRegistrationDAO;

@Controller
public class UserController {

	
	@Autowired
	UserRegistrationDAO userRegistrationDAO;
	
	@RequestMapping(value="/a",method=RequestMethod.GET)
		public String HelloUser(UserRegistration ur ,ModelMap model)
		{
		String name = ur.getName();
		String address = ur.getAddress();
		String mobile = ur.getMobile();
		System.out.println("Name : "+name+" address : "+address+" mobile "+mobile);
				
		System.out.println("Name"+name);
		try {/*
			Configuration cfg=new Configuration();
			cfg.configure("/hibernate.cfg.xml");
			SessionFactory sessionFactory = cfg.buildSessionFactory();
			//Session session=sessionFactory.openSession();
			Date d1=new Date();
			System.out.println("Starting Time *** : "+System.currentTimeMillis());
			StatelessSession sl = sessionFactory.openStatelessSession();
			Transaction tx = sl.beginTransaction();
			for(int i=1;i<10;i++)
			{
				ur.setId(i);
				ur.setAddress("A"+i);
				ur.setName("N"+i);
				ur.setMobile("M"+i);
				sl.insert(ur);
			}
			tx.commit();
			//session.save(ur);
			
			session.save(ur);
			Transaction tx = session.beginTransaction();
			tx.commit();
		  
		   
		    sl.close();
		    sessionFactory.close();		    
			
				
		    System.out.println("Ending Time *** : "+System.currentTimeMillis());
			
		*/} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		//System.out.println(userRegistration.getName());
		
		try {
			//System.out.println("Name : "+res.getParameter("name"));
			//System.out.println("Address : "+ur.getAddress());
			//System.out.println("Mobile : "+ur.getMobile());
		} catch (Exception e) {
			// TODO: handle exception
		}
		//System.out.println("Pavan@@"+name);
		//System.out.println("Pavan##"+name2);
		/*model.addAttribute("name",ur.getName());
		model.addAttribute("address",ur.getAddress());
		model.addAttribute("mobile",ur.getMobile());
		model.addAttribute("ur",ur);*/
		
		try {
			List<UserRegistration> uregList=new ArrayList<UserRegistration>();
			uregList=userRegistrationDAO.list();
			System.out.println("Pavan : "+uregList);
			
		} catch (Exception e) {
		e.printStackTrace();
		}
		
			
			return "userlogin";
		}
	}


