package tm.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import com.itextpdf.text.log.SysoCounter;

import tm.bean.UserRegistration;

public class UserRegistrationDAO extends GenericHibernateDAO<UserRegistration, Integer> {

	public UserRegistrationDAO() {
		super(UserRegistration.class);
	}
	
	@Autowired  
	 public SessionFactory sessionFactory; 
	
	@Transactional(readOnly=false)
	public List<UserRegistration> list()
	{
		List<UserRegistration> userRegList=new ArrayList<UserRegistration>();
		try {
			userRegList =	findByCriteria(Order.asc("id"));
			System.out.println(userRegList);
			for(UserRegistration ur:userRegList)
			{
				System.out.println("Name : "+ur.getName()+"Address "+ur.getAddress());
				
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		return userRegList;
	}
}
